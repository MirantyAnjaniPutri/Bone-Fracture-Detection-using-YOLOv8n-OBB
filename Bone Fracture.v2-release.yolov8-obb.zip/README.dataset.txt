# bone fracture > release
https://universe.roboflow.com/roboflow-100/bone-fracture-7fylg

Provided by a Roboflow user
License: CC BY 4.0

This dataset was originally created by [Jason Zhang, Caden Li](https://universe.roboflow.com/science-research/). To see the current project, which may have been updated since this version, please go here: https://universe.roboflow.com/science-research/science-research-2022:-bone-fracture-detection.

This dataset is part of [RF100](https://rf100.org), an [Intel-sponsored](https://www.intel.com/) initiative to create a new object detection benchmark for model generalizability.

Access the RF100 Github repo: https://github.com/roboflow-ai/roboflow-100-benchmark